from main.repo import Repo
from main.service import Service


repo = Repo()
service = Service(repo)
service.save_solution()
